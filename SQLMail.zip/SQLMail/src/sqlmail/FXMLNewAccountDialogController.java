package sqlmail;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import mail.MailDAO;

/**
 * FXML Controller class
 *
 * @author Joe Gregg
 */
public class FXMLNewAccountDialogController implements Initializable {

    private MailDAO model;
    
    @FXML
    TextField userName;
    @FXML
    PasswordField password;
    @FXML
    Label errorMessage;
    
    @FXML
    private void accept(ActionEvent evt) {
        if(model.createNewAccount(userName.getText(), password.getText())) {
           userName.getScene().getWindow().hide();
        }
        else
            errorMessage.setText("Can not log in.");
    }
    
    @FXML
    private void cancel(ActionEvent evt) {
        userName.getScene().getWindow().hide();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public void setModel(MailDAO dao) {
        model = dao;
    }
    
}
