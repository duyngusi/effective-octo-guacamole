package sqlmail;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import mail.Message;

/**
 * FXML Controller class
 *
 * @author Joe Gregg
 */
public class FXMLReadDialogController implements Initializable {

    @FXML
    Label fromLabel;
    @FXML
    Label sentLabel;
    @FXML
    Label subjectLabel;
    @FXML
    TextArea bodyArea;
    
    @FXML
    private void accept(ActionEvent evt) {
        bodyArea.getScene().getWindow().hide();
    }
    
    public void setMessage(Message msg) {
        fromLabel.setText(msg.getSender());
        sentLabel.setText(msg.getTime());
        subjectLabel.setText(msg.getSubject());
        bodyArea.setText(msg.getContents());
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
