package sqlmail;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import mail.Handle;
import mail.MailDAO;
import mail.Message;

/**
 *
 * @author Joe Gregg
 */
public class FXMLDocumentController implements Initializable {
    
    private MailDAO model;
    
    @FXML
    private ListView handlesList;
    
    @FXML
    private void logIn(ActionEvent event) {
        Stage parent = (Stage) handlesList.getScene().getWindow();
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("FXMLLogInDialog.fxml"));
            Parent root = (Parent)loader.load();
            Scene scene = new Scene(root);
            Stage dialog = new Stage();
            dialog.setScene(scene);
            dialog.setTitle("Log In");
            dialog.initOwner(parent);
            dialog.initModality(Modality.WINDOW_MODAL);
            dialog.initStyle(StageStyle.UTILITY);
            dialog.setX(parent.getX() + parent.getWidth()/4);
            dialog.setY(parent.getY() + parent.getHeight()/3);
            
            FXMLLogInDialogController controller = (FXMLLogInDialogController) loader.getController();
            controller.setModel(model);
            dialog.show();
        } catch(Exception ex) {
            System.out.println("Could not open dialog.");
            ex.printStackTrace();
        }
    }
    
    @FXML
    private void newAccount(ActionEvent event) {
        Stage parent = (Stage) handlesList.getScene().getWindow();
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("FXMLNewAccountDialog.fxml"));
            Parent root = (Parent)loader.load();
            Scene scene = new Scene(root);
            Stage dialog = new Stage();
            dialog.setScene(scene);
            dialog.setTitle("Create New Account");
            dialog.initOwner(parent);
            dialog.initModality(Modality.WINDOW_MODAL);
            dialog.initStyle(StageStyle.UTILITY);
            dialog.setX(parent.getX() + parent.getWidth()/4);
            dialog.setY(parent.getY() + parent.getHeight()/3);
            
            FXMLNewAccountDialogController controller = (FXMLNewAccountDialogController) loader.getController();
            controller.setModel(model);
            dialog.show();
        } catch(Exception ex) {
            System.out.println("Could not open dialog.");
            ex.printStackTrace();
        }
    }
    
    @FXML
    private void logOut(ActionEvent event) {
        model.logOut();
    }
    
    @FXML
    private void readMessage(ActionEvent event) {
        Handle handle = (Handle) handlesList.getSelectionModel().getSelectedItem();
        Message msg = model.getMessage(handle.getID());
        
        Stage parent = (Stage) handlesList.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("FXMLReadDialog.fxml"));
            Parent root = (Parent)loader.load();
            Scene scene = new Scene(root);
            Stage dialog = new Stage();
            dialog.setScene(scene);
            dialog.setTitle("Read Message");
            dialog.initOwner(parent);
            dialog.initModality(Modality.WINDOW_MODAL);
            dialog.initStyle(StageStyle.UTILITY);
            dialog.setX(parent.getX() + parent.getWidth()/4);
            dialog.setY(parent.getY() + parent.getHeight()/3);
            
            FXMLReadDialogController controller = (FXMLReadDialogController) loader.getController();
            controller.setMessage(msg);
            dialog.show();
        } catch(Exception ex) {
            System.out.println("Could not open dialog.");
            ex.printStackTrace();
        }
    }
    
    @FXML
    private void newMessage(ActionEvent event) {
        Stage parent = (Stage) handlesList.getScene().getWindow();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("FXMLComposeDialog.fxml"));
            Parent root = (Parent)loader.load();
            Scene scene = new Scene(root);
            Stage dialog = new Stage();
            dialog.setScene(scene);
            dialog.setTitle("Compose Message");
            dialog.initOwner(parent);
            dialog.initModality(Modality.WINDOW_MODAL);
            dialog.initStyle(StageStyle.UTILITY);
            dialog.setX(parent.getX() + parent.getWidth()/4);
            dialog.setY(parent.getY() + parent.getHeight()/3);
            
            FXMLComposeDialogController controller = (FXMLComposeDialogController) loader.getController();
            controller.setModel(model);
            dialog.show();
        } catch(Exception ex) {
            System.out.println("Could not open dialog.");
            ex.printStackTrace();
        }
    }
    
    @FXML
    private void deleteMessage(ActionEvent event) {
        Handle selected = (Handle) handlesList.getSelectionModel().getSelectedItem();
        if(selected != null) {
            model.deleteMessage(selected.getID());
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        model = new MailDAO();
        handlesList.setItems(model.getHandles());
    }    
    
}
