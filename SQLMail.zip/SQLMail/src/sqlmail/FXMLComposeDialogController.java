package sqlmail;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import mail.MailDAO;
import mail.Message;

public class FXMLComposeDialogController implements Initializable {
    
    private MailDAO model;
    
    @FXML
    TextField toField;
    @FXML
    TextField subjectField;
    @FXML
    TextArea bodyArea;
    
    @FXML
    private void accept(ActionEvent evt) {
        Message newMessage = new Message(model.getUserName(),toField.getText(),subjectField.getText(),bodyArea.getText());
        model.sendMessage(newMessage);
        bodyArea.getScene().getWindow().hide();
    }
    
    @FXML
    private void cancel(ActionEvent evt) {
       bodyArea.getScene().getWindow().hide();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public void setModel(MailDAO dao) {
        model = dao;
    }
}
