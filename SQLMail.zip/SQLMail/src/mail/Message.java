package mail;

import java.util.Calendar;
import java.text.DateFormat;
import java.io.Serializable;
import java.text.ParseException;

/* Messages are immutable objects that store an email message.
   Making Messages impossible to modify greatly simplifies the
   design of the application and removes the potential for problems
   when we send the same message to multiple recipients. */
import java.text.SimpleDateFormat;
public class Message implements Serializable {
  private String sender;
  private String recipients;
  private String subject;
  private String contents;
  private Calendar timeStamp;

  public Message(String sender,String recipients,String subject,String contents) {
    this.sender = sender;
    this.recipients = recipients;
    this.subject = subject;
    this.contents = contents;
    timeStamp = Calendar.getInstance();
  }
  
   public Message(String sender,String recipients,String subject,String contents,String time) {
       this.sender = sender;
       this.recipients = recipients;
       this.subject = subject;
       this.contents = contents;
       timeStamp = Calendar.getInstance();
       try {
           timeStamp.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(time));
       } catch (ParseException ex) {
           ex.printStackTrace();
       }
  }

  public String getSender() { return sender; }
  public String getRecipients() { return recipients; }
  public String getSubject() { return subject; }
  public String getContents() { return contents; }
  public String getTime() { return DateFormat.getDateInstance().format(timeStamp.getTime()); }
}